exports.handler = async () => {
    return {
        body: 'Hello from Lambda Dev\n'
    };
};
